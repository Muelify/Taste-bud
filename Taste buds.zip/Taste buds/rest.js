'strict'
document.addEventListener("shown.bs.offcanvas", function () {
  document.body.style.paddingRight = "0";
});
document.addEventListener("hidden.bs.offcanvas", function () {
  document.body.style.paddingRight = "0";
});
